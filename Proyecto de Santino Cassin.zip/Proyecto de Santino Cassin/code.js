var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["9166346d-158c-408d-9070-5890aed8031b","105c9d9d-829a-478a-950f-5456f48fe0b4","ae1ad899-472b-420b-b1b2-69411958c2e5","c86adf57-b2e3-4b64-b446-2a463afa6fa2"],"propsByKey":{"9166346d-158c-408d-9070-5890aed8031b":{"name":"playerb","sourceUrl":"assets/api/v1/animation-library/gamelab/K9EpOkpRKq.sejaHAWAeqjtwQI7sfWZl/category_retro/retroaliens_21.png","frameSize":{"x":356,"y":400},"frameCount":1,"looping":true,"frameDelay":1,"version":"K9EpOkpRKq.sejaHAWAeqjtwQI7sfWZl","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":356,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/K9EpOkpRKq.sejaHAWAeqjtwQI7sfWZl/category_retro/retroaliens_21.png"},"105c9d9d-829a-478a-950f-5456f48fe0b4":{"name":"fondo","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"wKjSyB8Ckr02zSZHcuU5EO6_rOH4rCEJ","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/105c9d9d-829a-478a-950f-5456f48fe0b4.png"},"ae1ad899-472b-420b-b1b2-69411958c2e5":{"name":"fondo1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"xvzG8svrumBlU30QMMBKm4Lx3nRRPEGi","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/ae1ad899-472b-420b-b1b2-69411958c2e5.png"},"c86adf57-b2e3-4b64-b446-2a463afa6fa2":{"name":"player","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"RMitU.PMzH41FVTM3oNZWQlyd5wkkrnQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/c86adf57-b2e3-4b64-b446-2a463afa6fa2.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//crear el punatje
var score = 0;
//poner texto en la pantalla y color
text("score:", 0, 15);
stroke("yellow");
//crear los sprites
var player = createSprite(200, 10, 25, 25);
player.shapeColor = "Black";
var velocity = 10;
var velocitylaser = 10;
var playing = true;
var laseres = [];
player.setAnimation("player");
player.scale=0.4;

function draw() {
  createEdgeSprites();
  player.bounceOff(edges);
  
  if(playing){
    isPlaying();
  } else {
    isNotPlaying();
  }
  drawSprites();
  textSize(12);
  text("Echo por Santino Cassin", 265, 390);
}


function isPlaying(){
  score+=1;
  background("white");
  if(score % 20 == 0){
    var laser = createSprite(randomNumber(0, 400), 400, randomNumber(50, 125), 10);
    laser.shapeColor = "Red";
    laseres.push(laser);
  }
  
  
  text("SCORE: "+score,160, 180 );
  if (keyDown("left")) {
    player.x=player.x-velocity;
  }
  if (keyDown("right")) {
    player.x=player.x+velocity;
  }
  
  
  for(var i=0;i<laseres.length; i++){
    laseres[i].y=laseres[i].y-velocitylaser;
    if (player.isTouching(laseres[i])) {
      playing = false;
    }
    if(laseres[i].y < -10){
      velocity+=0.01;
      velocitylaser+=0.005;
      laseres[i].destroy();
    }
  }
}


function isNotPlaying(){
  background("Black");
  text("GAME OVER", 160, 200);
  text("SCORE: "+score,160, 180 );
  textSize(40);
  stroke("Yellow");
 if (keyDown("space")){
    retry();   
 }
}


function retry() {
  player.y=10;
  player.x=200;
  velocity = 10;
  velocitylaser = 10;
  playing = true;
  score = 0;
  for(var i=0;i<laseres.length; i++){
    laseres[i].destroy();
  }
  laseres = [];
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
